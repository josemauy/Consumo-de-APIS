const apiUrl = "https://pokeapi.co/api/v2/pokemon/";
const apiButton = document.getElementById('apiButton');
const apiData = document.getElementById("apiData");
const base_experience = document.getElementById('base_experience');
const name = document.getElementById('name')
const types = document.getElementById('types')
const sprites = document.getElementById('sprites')
const abilities1 = document.getElementById('abilities1')
const abilities2 = document.getElementById('abilities2')
let NombrePokemonInput = document.querySelector('.NombrePokemon');

// Función para llamar a la API y mostrar los datos
const callApi = () => {
    const NombrePokemon = NombrePokemonInput.value.trim(); // Obtener el valor del input y quitar espacios en blanco
    const url = `${apiUrl}${NombrePokemon}`;
    fetch(url)
    .then(res => res.json())
    .then(data => {
        console.log(data);
        //apiData.innerText = JSON.stringify(data);
        base_experience.innerText = `Experiencia base: ${JSON.stringify(data.base_experience)}`
        name.innerText = `Nombre del pokemon: ${JSON.stringify(data.name)}`
        types.innerText = `El pokemon es tipo: ${data.types[0].type.name}` // Obtener el primer tipo del array de tipos`
        abilities1.innerText =  `Habilidad 1: ${data.abilities[0].ability.name}`
        abilities2.innerText =  `Habilidad 2: ${data.abilities[1].ability.name}`
        
        // Reemplazar la imagen existente con la nueva imagen del Pokémon
        reemplazarImagenExistente(data);
    })
    .catch(e => console.error(new Error(e)));
}

// Función para reemplazar la imagen existente con la nueva imagen del Pokémon
function reemplazarImagenExistente(data) {
    // Eliminar la imagen existente si existe
    const imagenExistente = sprites.querySelector('img');
    if (imagenExistente) {
        imagenExistente.remove();
    }

    // Crear un nuevo elemento img para la nueva imagen
    const nuevaImagen = document.createElement('img');

    // Establecer la URL de la nueva imagen
    nuevaImagen.src = data.sprites.front_default;
    nuevaImagen.alt = 'Imagen del Pokémon';
 
    // Agregar la nueva imagen al contenedor 'sprites'
    sprites.appendChild(nuevaImagen);
}

// Agregar el evento click al botón y llamar a la función callApi
apiButton.addEventListener('click', callApi);
