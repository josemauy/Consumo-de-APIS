// URL base de la API de OpenWeatherMap para obtener información meteorológica
// const apiUrl = 'https://api.openweathermap.org/data/2.5/weather';
// const apiKey = '4f8b315130986a49da03aac23d34ff8a'; // Reemplaza 'tu_clave_de_api' con tu propia clave de API

let BotonBuscar = document.querySelector(".BotonBuscar");
let CiudadIngresada = document.querySelector('.CiudadIngresada');
let temperature = document.querySelector('.temp');
let summary = document.querySelector('.sumari');
let locationElement = document.querySelector('.location');
let windInfoElement = document.querySelector('.wind-info'); // Elemento para mostrar información de viento
let sysInfoElement = document.querySelector('.sys-info'); // Elemento para mostrar información del sistema
const kelvin = 273.15;
const apiKey = "4f8b315130986a49da03aac23d34ff8a";

// Función para obtener datos climáticos basados en una ubicación
function getWeatherByLocation(location) {
  const url = `https://api.openweathermap.org/data/2.5/weather?q=${location}&appid=${apiKey}`;

  fetch(url)
    .then((response) => {
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      return response.json();
    })
    .then((data) => {
      console.log(data);

      temperature.textContent = Math.floor(data.main.temp - kelvin) + "°C";
      summary.textContent = data.weather[0].description;
      locationElement.textContent = `${data.name}, ${data.sys.country}`;
      
      // Actualizar información de viento en la página
      const windInfo = `Wind: ${data.wind.speed} m/s, Direction: ${data.wind.deg}°`;
      windInfoElement.textContent = windInfo;

      // Actualizar información del sistema en la página
      const sysInfo = `Country: ${data.sys.country}`;
      sysInfoElement.textContent = sysInfo;
    })
    .catch((error) => {
      console.error('There was a problem with your fetch operation:', error);
    });
}

function reemplazarImagenExistente(data) {
  // Eliminar la imagen existente si existe
  const imagenExistente = sprites.querySelector('img');
  if (imagenExistente) {
      imagenExistente.remove();
  }

  // Crear un nuevo elemento img para la nueva imagen
  const nuevaImagen = document.createElement('img');

  // Establecer la URL de la nueva imagen
  nuevaImagen.src = data.sprites.front_shiny;
  nuevaImagen.alt = 'Imagen del Pokémon';

  // Agregar la nueva imagen al contenedor 'sprites'
  sprites.appendChild(nuevaImagen);
}

window.addEventListener("load", () => {
  // Llamamos a la función con la ubicación "Paris" como ejemplo al cargar la página
  getWeatherByLocation("");

  // Asociamos el evento click al botón de búsqueda
  BotonBuscar.addEventListener("click", () => {
    const ciudad = CiudadIngresada.value.trim();
    if (ciudad) {
      getWeatherByLocation(ciudad);
    } else {
      alert("Por favor ingrese una ciudad.");
    }
  });
});