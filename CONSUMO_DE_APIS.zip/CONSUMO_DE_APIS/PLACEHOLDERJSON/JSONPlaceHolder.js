// URL base de la API de JSONPlaceholder para obtener datos de fotos
const apiUrl = 'https://jsonplaceholder.typicode.com/photos';
const fotos = [
    {
        titulo: 'Gato',
        src: 'img/gato.jpg',
        alt: 'Gato',
        descripcion: 'Es un animal mamífero. Tiene el cuerpo cubierto de pelo, tiene cuatro patas y rabo. Tiene unas uñas muy afiladas que utiliza para cazar y sujetar ratas y ratones. Utiliza la lengua para limpiarse y sus grandes bigotes para guiarse por la noche.'
    },
    {
        titulo: 'Guepardo',
        src: 'img/guepardo.jpg',
        alt: 'Guepardo',
        descripcion: 'Su coloración es amarillenta con pequeñas manchas negras y en la punta de la cola presenta círculos negros que asemejan anillos. A comparación del resto de los félidos sus garras no son retráctiles y se diferencia de los leopardos por tener cuerpos muy delgados.'
    },
    {
        titulo: 'Jaguar',
        src: 'img/jaguar.jpg',
        alt: 'Jaguar',
        descripcion: 'El jaguar es un imponente felino que puede ser reconocido más fácilmente por las manchas que cubren su bronceado pelaje. Tiene patas gruesas y robustas y orejas cortas y redondas. De todos los felinos, el jaguar tiene la mandíbula más poderosa.'
    },
    {
        titulo: 'Leon',
        src: 'img/leon.jpg',
        alt: 'Leon',
        descripcion: 'El león es uno de los cuatro grandes félidos pertenecientes al género Panthera. El macho adulto es fácilmente reconocible por su gran tamaño y llamativa melena, y tiene un peso aproximado de 150 o 250 kg.'
    },
    {
        titulo: 'Leopardo',
        src: 'img/leopardo.jpg',
        alt: 'Leopardo',
        descripcion: 'El leopardo es un felino salvaje, vivíparo porque nace del vientre de la madre y es carnívoro. Posee una cabeza corta, redondeada como una pelota, tiene orejas delgadas, pequeñas y puntiagudas. Tiene ojos pequeños y verdosos como la hierba en primavera. Su hocico es gordo y alargado, con grandes bigotes.'
    },
    {
        titulo: 'Lince',
        src: 'img/lince.jpg',
        alt: 'Lince',
        descripcion: 'Es un félido de tamaño mediano de patas largas y cola corta. Tiene la cara redondeada, con grandes orejas rematadas por pinceles de pelos negros, y largas patillas. El pelaje es de tonos parduzcos, moteado de manchas negras.'
    },
    {
        titulo: 'Pantera',
        src: 'img/pantera.jpg',
        alt: 'Pantera',
        descripcion: 'es el mamífero de mayor tamaño después del tigre, y su peso puede alcanzar los 250 kilos. Los machos y las hembras se distinguen fácilmente gracias a que los primeros poseen melena, cuya longitud y color varía de acuerdo con la edad, la genética, cuestiones hormonales y el desgaste.'
    },
    {
        titulo: 'Puma',
        src: 'img/puma.jpg',
        alt: 'Puma',
        descripcion: 'Las orejas son redondeadas. La cola es larga y representa cerca de un tercio de la longitud total del animal. El pelaje es variable en longitud y textura, aunque normalmente corto y algo áspero, de color uniforme, pardo grisáceo claro a pardo oscuro rojizo.'
    },
    {
        titulo: 'Tigre',
        src: 'img/tigre.jpg',
        alt: 'Tigre',
        descripcion: 'Los tigres son los más emblemáticos de los grandes felinos. Su hermoso pelaje negro y anaranjado, además de sus largos bigotes blancos, son fuente de admiración e inspiración para muchos. Pero a pesar de ser tan venerados, también son vulnerables a la extinción.'
    },
    {
        titulo: 'Tigrillo',
        src: 'img/tigrillo.jpg',
        alt: 'Tigrillo',
        descripcion: 'De tamaño pequeño, pero más grande que un gato doméstico. El pelaje es suave y corto; dorso de color amarillo pardo o marrón grisáceo con hileras longitudinales de manchas y líneas negras. Es nocturno, arborícola, terrestre y solitario; captura sus presas en el suelo.'
    }
];


// Función para obtener datos de usuarios desde la API
async function obtenerDatosFotos() {
    try {
        const respuesta = await fetch(apiUrl);
        if (!respuesta.ok) {
            throw new Error('Error al obtener los datos de la API');
        }
        const datos = await respuesta.json();
        return datos;
    } catch (error) {
        console.error('Error en la solicitud:', error);
        throw error; // Propagar el error hacia arriba
    }
}

async function mostrarPrimeras10Fotos() {
    try {
        // Obtener datos de fotos
        const fotos = await obtenerDatosFotos();

        // Obtener el contenedor de fotos en el HTML
        const photoContainer = document.querySelector('.photo-container');

        // Mostrar solo las primeras 10 fotos
        const firstTenPhotos = fotos.slice(0, 10);
        firstTenPhotos.forEach(photo => {
            // Crear un elemento div para cada foto
            const photoElement = document.createElement('div');
            photoElement.classList.add('photo');

            // Crear una imagen y establecer su URL y título
            const image = document.createElement('img');
            image.src = photo.thumbnailUrl;
            image.alt = photo.title;

            // Crear un elemento p para mostrar el título de la foto
            const titleElement = document.createElement('p');
            titleElement.textContent = photo.title;

            // Agregar la imagen y el título al elemento div de la foto
            photoElement.appendChild(image);
            photoElement.appendChild(titleElement);

            // Agregar el elemento div de la foto al contenedor de fotos
            photoContainer.appendChild(photoElement);
        });
    } catch (error) {
        console.error('Error en la aplicación:', error);
    }
}

// Llamamos a la función para mostrar las primeras 10 fotos cuando la página se cargue
mostrarPrimeras10Fotos();

/* // Código para mostrar las primeras 10 fotos
async function mostrarPrimeras10Fotos() {
    try {
        // Obtener el contenedor de fotos en el HTML
        const photoContainer = document.querySelector('.photo-container');

        // Mostrar solo las primeras 10 fotos del array
        for (let i = 0; i < 10; i++) {
            // Obtener la información de la foto del array
            const foto = fotos[i];

            // Crear un elemento div para la foto
            const photoElement = document.createElement('div');
            photoElement.classList.add('photo');

            // Crear una imagen y establecer su URL y título
            const image = document.createElement('img');
            image.src = foto.src;
            image.alt = foto.alt;

            // Crear un elemento h2 para mostrar el título de la foto
            const titleElement = document.createElement('h2');
            titleElement.textContent = foto.titulo;

            // Crear un elemento p para mostrar la descripción de la foto
            const descriptionElement = document.createElement('p');
            descriptionElement.textContent = foto.descripcion;

            // Agregar la imagen, el título y la descripción al elemento div de la foto
            photoElement.appendChild(image);
            photoElement.appendChild(titleElement);
            photoElement.appendChild(descriptionElement);

            // Agregar el elemento div de la foto al contenedor de fotos
            photoContainer.appendChild(photoElement);
        }
    } catch (error) {
        console.error('Error en la aplicación:', error);
    }
} */
